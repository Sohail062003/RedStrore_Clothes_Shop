
<?php
  include('../include/connect.php');
  include('../function/common_function.php');
  session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>online | Ecomerce website</title>
    
    <link rel="stylesheet" href="../css/style.css">
    
     <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,300&display=swaprel= "
        stylesheet">

    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.0/css/fontawesome.min.css">

        <!-- bootstrap link  -->

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <style>
        /* .user_row{
            ma;
        } */
        body{
            overflow-x: hidden;
        }
        .user_col{
            width: 200px;
            height: 33px;
            /* margin-left: 350px;
            margin-top: auto; */
        }
        .profile_img{
            width: 90%;
            /* height: 100%; */
            margin: auto;
            display: block;
            object-fit: contain;
        } 
        .edit_image{
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        
    </style>

</head>

<body>
<div class="header">
        <div class="container">
            <div class="navbar h-class-resp">
                <div class="logo v-class-resp">
                    <img src="../images/logo.png" alt="logo" width="125px">
                </div>
                <nav>
                    <ul class="nav-list v-class-resp mb-0">
                        <li><a href="../index.php" class="home text-decoration-none text-dark">Home</a></li>
                        <li><a href="kids.html" class="product text-decoration-none text-dark">product</a></li>
                        <li><a href="" class="about text-decoration-none text-dark">About</a></li>
                        <li><a href="" class="contact text-decoration-none text-dark">Contact</a></li>

                <?php
                if(!isset($_SESSION['username'])){
                    echo "<li><a href='user_login.php' class='account text-decoration-none text-dark'>Login</a></li>";
                }else{
                    echo "<li><a href='logout.php' class='account text-decoration-none text-dark'>Logout</a></li>";
                }
            ?>
        <!-- <li><a href="" class="account text-decoration-none text-dark">Login</a></li> -->
    </ul>
</nav>
            <a href="../cart.php"><img src="../images/cart.png" alt="" width="30px" height="30px"
                class="cart v-class-resp"></a>
                <!-- <img src="images/menu.png" class="menu-icon" onclick="menutoggle()">    -->
            <div class="burger">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </div>

    </div>
</div>

    

    <div class="user_row  mt-5">

        <div class="user_col  ">
        <ul class="navbar-nav bg-secondary text-center">
            <li class="nav-item bg-info">
                <a class="nav-link text-light" href="#"><h4>Your Profile</h4></a>
            </li>

            <?php
            $username=$_SESSION['username'];
            $user_image = "Select * from `user_table` where username='$username'";
            $user_image = mysqli_query($con,$user_image);
           $row_image=mysqli_fetch_array($user_image);
            $user_image = $row_image['user_image'];
            echo "<li class='nav-item '>
            <img src='./user_images/$user_image' alt='' class='profile_img my-4'>
        </li>";
            ?>

            <!-- <li class="nav-item ">
            <img src="../images/" alt="user img" class="profile_img my-4">
            </li> -->
            <li class="nav-item ">
                <a class="nav-link text-light" href="profile.php">pending orders</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link text-light" href="profile.php?edit_account">edit account</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link text-light" href="profile.php?my_order">My Orders</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link text-light" href="profile.php?delete_account">delete account</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link text-light" href="logout.php">logout</a>
            </li>
        </ul>
        </div>
        <div class="user_col-md-10 text-center mb-4 my-4">
           <?php get_user_order_datails(); 

           if(isset($_GET['edit_account'])){
            include('edit_account.php');
           }
           if(isset($_GET['my_order'])){
            include('user_orders.php');
           }
           ?>
        </div>
        
    </div>
    




   

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    </body>
</html>