<?php
include('../include/connect.php');
// include('function/common_function.php');
session_start();
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ecommerce | checkout </title>

    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <!-- css -->
    <link rel="stylesheet" href="../css/style.css">

    <style>
        .cart_images {
            width: 80px;
            height: 80px;
            object-fit: contain;
        }
        
        a{
            text-decoration: none;
            color:#555;
        }
    </style>

</head>

<body>

    <div class="header">
        <div class="container">
            <div class="navbar h-class-resp">
                <div class="logo v-class-resp">
                    <img src="../images/logo.png" alt="logo" width="125px">
                </div>
                <nav>
                    <ul class="nav-list v-class-resp mb-0">
                        <li><a href="../index.php" class="home text-decoration-none text-dark">Home</a></li>
                        <li><a href="kids.html" class="product text-decoration-none text-dark">product</a></li>
                        <li><a href="" class="about text-decoration-none text-dark">About</a></li>
                        <li><a href="" class="contact text-decoration-none text-dark">Contact</a></li>

                        <?php
                        if(!isset($_SESSION['username'])){
                            echo "<li><a href='./users_area/user_login.php' class='account text-decoration-none text-dark'>Login</a></li>";
                        }else{
                            echo "<li><a href='logout.php' class='account text-decoration-none text-dark'>Logout</a></li>";
                        }
                        ?>

                        <!-- <li><a href="" class="account text-decoration-none text-dark">Login</a></li> -->
                    </ul>
                </nav>
                <a href="cart.php"><img src="../images/cart.png" alt="" width="30px" height="30px"
                        class="cart v-class-resp"></a>
                <!-- <img src="images/menu.png" class="menu-icon" onclick="menutoggle()">    -->
                <div class="burger">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </div>

        </div>
    </div>
 <!-- condition of checkout page -->
    <div class="container">
        <div class="small-container">
            <div class="checkoutrow">
                <?php
                if(!isset($_SESSION['username'])){
                    include('user_login.php');
                }else{
                    include('payment.php');
                }
                ?>

            </div>
        </div>
    </div> 


    <!-- -------------foter------------- -->
    <?php
    include('../footer.php');
    ?>

    <script src="javascript/resp.js"></script>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
</body>

</html> 