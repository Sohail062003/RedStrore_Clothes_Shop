<?php
include('../include/connect.php');
if (isset($_POST['insert_cat'])) {
    $categorie_title = $_POST['cat_title'];

    // select the dat from datbase
    $select_query = "Select * from `categories` where category_title='$categorie_title'";
    $result_select = mysqli_query($con, $select_query);
    $number = mysqli_num_rows($result_select);
    if ($number > 0) {
        echo "<script> alert('ths categories is present inside the database') </script>";
    } else {

        $insert_query = "INSERT INTO `categories` (category_title) VALUES ( '$categorie_title')";
        $result = mysqli_query($con, $insert_query);

        if ($result) {
            echo "<script> alert('category has bee inserted successfully') </script>";
        }
    }
}
?>


<style>
    .input-group {
        max-width: 1200px;
        margin: auto;
    }

    .cat-title {
        width: 82%;
        margin-bottom: 20px;
        padding: 5px 4px;
    }

    .cat_button {
        margin: 5px 6px;
        padding: 5px 4px;
        background: #e8dada;
        border-radius: 6px;
    }

    .cat_button:hover {
        cursor: pointer;
        background: rgb(255 235 235);
    }

    h1 {
        text-align: center;
        margin: 15px;
    }
</style>

<form action="" method="post">
    <div class="input-group">
        <h1>Insert categories</h1>
        <input type="text" name="cat_title" placeholder="insert categories" class="cat-title">
        <input type="submit" name="insert_cat" value="insert categories" class="cat_button">
    </div>
</form>