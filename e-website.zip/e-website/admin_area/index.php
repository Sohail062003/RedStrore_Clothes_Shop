<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin panel</title>
    <link rel="stylesheet" href="index.css">
</head>

<body>
    <header>
        <nav class="">
            <div class="navbar">
                <img src="../images/logo.png" alt="logo"  width="100px">
            </div>
            <div class="navbar adm-nav">
                <a href="" class="login">welcome admin</a>
            </div>
            <div class="admin-img adm-nav">
                <img src="../images/user.png" alt="">
            </div>
        </nav>
    </header>

    <!-- class="logo" -->
    <!-- management -->

    <div class="management">
        <h1 class="title">Management details</h1>

        <div class="row">

            <!-- <div class="col-1">
                admin photo

                <div class="admin-img">
                    <img src="../images/logo.png" alt="logo" class="adm-logo">
                </div>
                <a href="">Admin name</a>

            </div> -->

            <div class="col-1">
                <!-- crud operations -->
                <div class="button">
                    <button><a href="insert_product.php" class="input-btn">Insert Product</a></button>
                    <button><a href="view_product.php" class="input-btn">View Product</a> </button>
                    <button><a href="index.php?insert_categories" class="input-btn">Insert Categories</a> </button>
                    <button><a href="" class="input-btn">View Categories</a> </button>
                    <button><a href="index.php?insert_brands" class="input-btn">Insert Brands</a> </button>
                    <button><a href="" class="input-btn">View Brands</a> </button>
                    <button><a href="" class="input-btn">All Orders</a> </button>
                    <button><a href="" class="input-btn">All Payment</a> </button>
                    <button><a href="" class="input-btn">List User</a> </button>
                    <button><a href="" class="input-btn ">Log Out</a></button>

                </div>
            </div>
        </div>
    </div>


    <!-- fourth child -->
    <div class="container">
        <?php
        if (isset($_GET['insert_categories'])) {
            include('insert_categories.php');
        }
        if (isset($_GET['insert_brands'])) {
            include('insert_brands.php');
        }
        ?>
    </div>

    
        <!-- footder -->
    <?php
    include('../footer.php');
    ?>
    
</body>

</html>