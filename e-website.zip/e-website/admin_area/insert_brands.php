<?php
    include('../include/connect.php');
    if(isset($_POST['insert_brand'])){
        $brand_title = $_POST['brand_title'];

        // select the dat from datbase
        $select_query = "Select * from `brands` where brand_title='$brand_title'";
        $result_select = mysqli_query($con,$select_query);
        $number=mysqli_num_rows($result_select);
        if($number>0){
            echo "<script> alert('this brand is present inside the database') </script>";
        }else{
            
        $insert_query =  "INSERT INTO `brands` (brand_title) VALUES ( '$brand_title')";
        $result = mysqli_query($con,$insert_query);

        if($result){
            echo "<script> alert('brand has bee inserted successfully') </script>";
        }
    }
}
?>


<style>
    .input-group{
        max-width: 1200px;
        margin:auto;
    }
    .brands-title{
        width: 82%;
        margin-bottom: 20px;
        padding: 5px 4px;
    }

    .brands_button{
        margin: 5px 6px;
        padding: 5px 4px;
        background: #e8dada;
        border-radius: 6px ;
    }
    .brands_button:hover{
        cursor: pointer;
        background: rgb(255 235 235);
    }
    h1 {
        text-align: center;
        s
    }
</style>
<form action="" method="post">
<h1>Insert Brands</h1>
    <div class="input-group">
        <input type="text" name="brand_title" placeholder="insert brands" class="brands-title">
        <input type="submit" name="insert_brand" value="insert brands" class="brands_button">
    </div>
</form>