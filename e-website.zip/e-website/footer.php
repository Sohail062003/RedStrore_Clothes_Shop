<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .footer-all{
    
    background-color: #000;
    color: #8a8a8a;
    font-size: 14px;
    padding: 16px 7px 20px; 
    /* margin-top: 50px ;
    /* top: 49vh;   */
    margin-top: 105px ;
    }
</style>
<body>
    <div class="footer-all "> 
        <hr>
            <p class="copy-right">Copyright &copy; 2027 - www.RedStore.com - All rights reserved</p>
</div>

</body>
</html>