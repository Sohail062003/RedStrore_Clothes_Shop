burger = document.querySelector('.burger')
navbar = document.querySelector('.navbar')
navlist = document.querySelector('.nav-list')
logo = document.querySelector('.logo')
cart = document.querySelector('.cart')



burger.addEventListener('click',()=>{
    navbar.classList.toggle('h-class-resp');
    navlist.classList.toggle('v-class-resp');
    logo.classList.toggle('v-class-resp');
    cart.classList.toggle('v-class-resp');
})


