<?php

// include('./include/connect.php');

function getproducts(){
        global $con;
        $select_query = "Select * from `products` "; // it will only  display nine products  
        $result_query = mysqli_query($con, $select_query);
        
        while($row = mysqli_fetch_assoc($result_query)){
            $product_id = $row['product_id'];
            $product_title = $row['product_title'];
            $product_description = $row['product_description'];
            $product_keywords= $row['product_keywords'];
            $product_image1 = $row['product_image1'];
            $product_price = $row['product_price'];
            $category_id = $row['category_id'];
            $brand_id = $row['brand_id'];

            
            // echo "<div class='col-4'>
            // <img src='./admin_area/product_images/$product_image1' alt='$product_image1'>
            // <h4>$product_title</h4>
            // <p>$product_description</p>
            // <p>$product_price</p>
            // </div>";

            echo "<div class='col-4'>
            <img src='./admin_area/product_images/$product_image1' alt=''>
            <h4>$product_title</h4>
            <p>$product_description</p>
            <p>$product_price</p>
            
            <a href='index.php?add_to_cart=$product_id' class='buy-btn'>add to cart</a>
        </div>";
            
        }
}

// displaying brands 
function getbrands(){
    global $con;
$select_brands= "Select * from `brands` ";
$result_brands = mysqli_query($con,$select_brands);

while($row_data = mysqli_fetch_assoc( $result_brands)){
    $brand_title = $row_data['brand_title']; 
    echo "<h2 class='title'>$brand_title</h2>";
}
}

// get ip address funtion 

function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
// $ip = getIPAddress();  
// echo 'User Real IP Address - '.$ip;  

// cart function 
function cart(){
    if(isset($_GET['add_to_cart'])){
    global $con;
    $ip = getIPAddress();
    $get_product_id = $_GET['add_to_cart'];
    $select_query = "Select * from `cart_details` where ip_address='$ip' and product_id=$get_product_id";
    $result_query = mysqli_query($con,$select_query);

    $num_of_rows=mysqli_num_rows($result_query);
    if($num_of_rows>0){
        echo "<script>alert('This item is already present in the cart')</script>";
        echo "<script>window.open('index.php','_self')</script>";
    }else{
        $insert_query = "insert into `cart_details` (product_id,ip_address,quantity)
         values ($get_product_id,'$ip',0)";
         $result_query = mysqli_query($con,$insert_query);
         echo "<script>alert('This item is added to cart')</script>";
         echo "<script>window.open('index.php','_self')</script>";


    }

    }
}

// total price function

function total_cart_price(){
    global $con; // this variable must be declare when function is created
    $ip = getIPAddress();
    $total=0;
    $cart_query = "Select *from `cart_details` where ip_address ='$ip'";
    $result = mysqli_query($con,$cart_query);

    while($row =mysqli_fetch_array($result)){
        $product_id = $row['product_id'];
        $select_products =  "Select *from `products` where product_id ='$product_id'";  // query 
        $result_product = mysqli_query($con,$select_products);

        while($row_product_price =mysqli_fetch_array($result_product)){
            $product_price =array($row_product_price['product_price']);
            $product_values =array_sum($product_price);
            $total +=$product_values;
        }

    }
    echo $total;
}

 function getusername(){
    global $con;
    if(isset($_GET['username'])){
        $get_username = $_GET['username'];
        $select = "select * from `user_table` where username='$get_username'";
        $result = mysqli_query($con,$select);

    $row = mysqli_num_rows($result);
    if($row>0){
       
        echo "<li><a href='#' class='login'>welcome $get_username </a></li>" ;
    }
}
 }

 function get_user_order_datails(){
    global $con;
    $username=$_SESSION['username'];
    $get_details = "Select * from `user_table` where username = '$username'";
    $result_query = mysqli_query($con,$get_details);
    while($row_query=mysqli_fetch_array($result_query)){
        $user_id = $row_query['user_id'];
        if(!isset($_GET['edit_account'])){
            if(!isset($_GET['my_order'])){
                if(!isset($_GET['delete_account'])){
                    $get_orders="select * from `user_orders` where user_id=$user_id and order_status='pending'";
                    $result_orders_query = mysqli_query($con,$get_orders);
                    $row_count = mysqli_num_rows($result_orders_query);
                    if($row_count>0){
                        echo "<h3 class='text-center text-success'>You have <span class ='text-danger'>$row_count </span> pending Orders</h3>
                        <p class='text-center'><a href='profile.php?my_order'>Order details</a></p>";
                    }else{
                        echo "<h3 class='text-center text-success'>You have zero pending orders</h3>
                        <p class='text-center'><a href='../index.php'>Explore products</a></p>";
                    }


                }
            }
        }
    }
 }

 


?>